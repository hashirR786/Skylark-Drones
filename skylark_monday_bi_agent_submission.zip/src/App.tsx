import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ChatInterface } from './components/ChatInterface';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { LeadershipStudio } from './components/LeadershipStudio';
import { DataExplorer } from './components/DataExplorer';
import { MondayConfigModal } from './components/MondayConfigModal';
import { INITIAL_DEALS, INITIAL_WORK_ORDERS } from './data/mockData';
import { Deal, WorkOrder, MondayConfig, CrossBoardMetrics } from './types';
import { computeOverallMetrics } from './services/dataResilience';
import { fetchBoardItems, mapMondayItemsToDeals, mapMondayItemsToWorkOrders } from './services/mondayApi';

export function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'dashboard' | 'leadership' | 'explorer' | 'monday'>('chat');
  const [deals, setDeals] = useState<Deal[]>(INITIAL_DEALS);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [isConfigOpen, setIsConfigOpen] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const [mondayConfig, setMondayConfig] = useState<MondayConfig>({
    apiKey: '',
    dealsBoardId: '',
    workOrdersBoardId: '',
    isConnected: false,
    syncStatus: 'idle',
  });

  const metrics: CrossBoardMetrics = computeOverallMetrics(deals, workOrders);

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleSyncData = async () => {
    setIsSyncing(true);

    if (mondayConfig.isConnected && mondayConfig.apiKey && (mondayConfig.dealsBoardId || mondayConfig.workOrdersBoardId)) {
      try {
        if (mondayConfig.dealsBoardId) {
          const fetchedDeals = await fetchBoardItems(mondayConfig.apiKey, mondayConfig.dealsBoardId);
          const mappedDeals = mapMondayItemsToDeals(fetchedDeals.items);
          if (mappedDeals.length > 0) setDeals(mappedDeals);
        }
        if (mondayConfig.workOrdersBoardId) {
          const fetchedWOs = await fetchBoardItems(mondayConfig.apiKey, mondayConfig.workOrdersBoardId);
          const mappedWOs = mapMondayItemsToWorkOrders(fetchedWOs.items);
          if (mappedWOs.length > 0) setWorkOrders(mappedWOs);
        }
        showNotification('Successfully synced live data from Monday.com boards!', 'success');
      } catch (err: any) {
        showNotification(`Monday.com sync notice: ${err.message || 'Falling back to cached data'}`, 'info');
      }
    } else {
      // Re-normalize and refresh built-in data
      setTimeout(() => {
        setDeals([...INITIAL_DEALS]);
        setWorkOrders([...INITIAL_WORK_ORDERS]);
        showNotification('Refreshed & re-indexed 346 deals and 176 work orders dataset.', 'success');
      }, 500);
    }

    setTimeout(() => {
      setIsSyncing(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#070c18] text-slate-100 flex flex-col font-sans selection:bg-teal-500/30 selection:text-teal-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        mondayConfig={mondayConfig}
        metrics={metrics}
        onOpenConfig={() => setIsConfigOpen(true)}
        isSyncing={isSyncing}
        onSync={handleSyncData}
      />

      {/* Floating Notification Toast */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 animate-slide-up">
          <div className={`px-4 py-3 rounded-xl text-xs font-semibold shadow-2xl border flex items-center space-x-2 ${
            notification.type === 'success' ? 'bg-emerald-950 border-emerald-500 text-emerald-200' :
            notification.type === 'error' ? 'bg-rose-950 border-rose-500 text-rose-200' :
            'bg-slate-900 border-teal-500 text-teal-200'
          }`}>
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            <span>{notification.message}</span>
          </div>
        </div>
      )}

      {/* Main Content Areas */}
      <main className="flex-1">
        {activeTab === 'chat' && (
          <ChatInterface deals={deals} workOrders={workOrders} />
        )}

        {activeTab === 'dashboard' && (
          <AnalyticsDashboard deals={deals} workOrders={workOrders} metrics={metrics} />
        )}

        {activeTab === 'leadership' && (
          <LeadershipStudio deals={deals} workOrders={workOrders} />
        )}

        {activeTab === 'explorer' && (
          <DataExplorer deals={deals} workOrders={workOrders} />
        )}
      </main>

      {/* Monday Configuration Modal */}
      <MondayConfigModal
        isOpen={isConfigOpen}
        onClose={() => setIsConfigOpen(false)}
        config={mondayConfig}
        onSaveConfig={(newCfg) => {
          setMondayConfig(newCfg);
          showNotification(newCfg.isConnected ? 'Connected to Monday.com!' : 'Running in Enterprise Demo Mode', 'success');
        }}
      />
    </div>
  );
}

export default App;
