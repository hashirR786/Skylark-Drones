import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  Filter, 
  Download, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  FileSpreadsheet,
  Tag
} from 'lucide-react';
import { Deal, WorkOrder } from '../types';
import { formatCurrencyINR } from '../services/dataResilience';

interface DataExplorerProps {
  deals: Deal[];
  workOrders: WorkOrder[];
}

export const DataExplorer: React.FC<DataExplorerProps> = ({ deals, workOrders }) => {
  const [activeBoard, setActiveBoard] = useState<'deals' | 'work_orders'>('deals');
  const [searchTerm, setSearchTerm] = useState('');
  const [sectorFilter, setSectorFilter] = useState('ALL');
  const [anomalyOnly, setAnomalyOnly] = useState(false);

  // Filter Deals
  const filteredDeals = deals.filter((d) => {
    const matchesSearch = 
      d.dealName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.clientCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.ownerCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.dealStage.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = sectorFilter === 'ALL' || d.sector.toLowerCase() === sectorFilter.toLowerCase();
    const matchesAnomaly = !anomalyOnly || d.anomalies.length > 0;
    return matchesSearch && matchesSector && matchesAnomaly;
  });

  // Filter Work Orders
  const filteredWOs = workOrders.filter((w) => {
    const matchesSearch = 
      w.dealName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.clientCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.serialNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.executionStatus.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = sectorFilter === 'ALL' || w.sector.toLowerCase() === sectorFilter.toLowerCase();
    const matchesAnomaly = !anomalyOnly || w.anomalies.length > 0;
    return matchesSearch && matchesSector && matchesAnomaly;
  });

  const exportCSV = () => {
    const dataToExport = activeBoard === 'deals' ? filteredDeals : filteredWOs;
    const header = Object.keys(dataToExport[0] || {}).filter(k => k !== 'rawData').join(',');
    const rows = dataToExport.map(item => {
      return Object.entries(item)
        .filter(([k]) => k !== 'rawData')
        .map(([_, v]) => `"${Array.isArray(v) ? v.join('; ') : (v ?? '')}"`)
        .join(',');
    });
    const csvContent = 'data:text/csv;charset=utf-8,' + [header, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Skylark_${activeBoard}_Cleaned.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const sectors = Array.from(
    new Set([
      ...deals.map(d => d.sector),
      ...workOrders.map(w => w.sector),
    ])
  ).filter(Boolean);

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Header & Board Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
              Cross-Board Data Explorer
            </span>
            <span className="text-xs text-slate-400">Live Normalization & Audit</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight mt-1">
            {activeBoard === 'deals' ? 'Sales Deal Funnel Records' : 'Work Order Execution & AR Records'}
          </h1>
        </div>

        {/* Board Toggle Buttons */}
        <div className="flex items-center space-x-2">
          <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center space-x-1">
            <button
              onClick={() => setActiveBoard('deals')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeBoard === 'deals'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Deals Funnel ({deals.length})
            </button>
            <button
              onClick={() => setActiveBoard('work_orders')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeBoard === 'work_orders'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Work Orders ({workOrders.length})
            </button>
          </div>

          <button
            onClick={exportCSV}
            className="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-teal-300 flex items-center space-x-1.5 transition-all"
            title="Export Cleaned Dataset as CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search deals, clients, serial #, owners..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-teal-500 outline-none"
          />
        </div>

        {/* Sector Filter */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            aria-label="Filter Explorer by Sector"
            className="w-full bg-transparent text-xs text-white outline-none"
          >
            <option value="ALL" className="bg-slate-900">All Sectors ({sectors.length})</option>
            {sectors.map((s, idx) => (
              <option key={idx} value={s} className="bg-slate-900">{s}</option>
            ))}
          </select>
        </div>

        {/* Anomaly Only Checkbox */}
        <label className="flex items-center space-x-2.5 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 cursor-pointer hover:bg-slate-850">
          <input
            type="checkbox"
            checked={anomalyOnly}
            onChange={(e) => setAnomalyOnly(e.target.checked)}
            className="rounded text-teal-500 focus:ring-0 w-4 h-4 bg-slate-950 border-slate-700"
          />
          <span className="text-xs font-semibold text-amber-300 flex items-center space-x-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Show Anomalies / Quality Flags Only</span>
          </span>
        </label>
      </div>

      {/* Main Data Table Container */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] custom-scrollbar">
          {activeBoard === 'deals' ? (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 sticky top-0 z-10">
                <tr>
                  <th className="p-3">Deal Name</th>
                  <th className="p-3">Client</th>
                  <th className="p-3">Sector</th>
                  <th className="p-3">Stage</th>
                  <th className="p-3">Probability</th>
                  <th className="p-3">Deal Value</th>
                  <th className="p-3">Weighted Value</th>
                  <th className="p-3">Tentative Close</th>
                  <th className="p-3">Owner</th>
                  <th className="p-3">Data Quality Flags</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredDeals.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-semibold text-white">{d.dealName}</td>
                    <td className="p-3 font-mono text-cyan-300">{d.clientCode}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-medium">
                        {d.sector}
                      </span>
                    </td>
                    <td className="p-3 max-w-xs truncate">{d.dealStage}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        d.closureProbabilityLabel === 'High' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        d.closureProbabilityLabel === 'Medium' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {d.closureProbabilityLabel}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-white">{formatCurrencyINR(d.dealValue)}</td>
                    <td className="p-3 text-teal-400">{formatCurrencyINR(d.weightedValue)}</td>
                    <td className="p-3 text-slate-400">{d.tentativeCloseDate || '-'}</td>
                    <td className="p-3 font-mono text-slate-400">{d.ownerCode}</td>
                    <td className="p-3">
                      {d.anomalies.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {d.anomalies.map((ano, aIdx) => (
                            <span key={aIdx} className="px-1.5 py-0.5 rounded bg-amber-950/40 border border-amber-500/30 text-[10px] text-amber-300 flex items-center space-x-1">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              <span>{ano}</span>
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Valid</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 sticky top-0 z-10">
                <tr>
                  <th className="p-3">Serial #</th>
                  <th className="p-3">Project / Deal</th>
                  <th className="p-3">Client</th>
                  <th className="p-3">Sector</th>
                  <th className="p-3">Execution Status</th>
                  <th className="p-3">Contract Value</th>
                  <th className="p-3">Invoiced</th>
                  <th className="p-3">Collected</th>
                  <th className="p-3">AR Outstanding</th>
                  <th className="p-3">Priority AR</th>
                  <th className="p-3">Data Quality Flags</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredWOs.map((wo) => (
                  <tr key={wo.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-mono text-teal-400 font-bold">{wo.serialNo}</td>
                    <td className="p-3 font-semibold text-white">{wo.dealName}</td>
                    <td className="p-3 font-mono text-cyan-300">{wo.clientCode}</td>
                    <td className="p-3">{wo.sector}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        wo.executionStatus === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        wo.executionStatus.includes('Ongoing') ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                        'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {wo.executionStatus}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-white">{formatCurrencyINR(wo.amountInclGst)}</td>
                    <td className="p-3 text-indigo-300">{formatCurrencyINR(wo.billedInclGst)}</td>
                    <td className="p-3 text-emerald-400">{formatCurrencyINR(wo.collectedInclGst)}</td>
                    <td className="p-3 font-bold text-rose-400">{formatCurrencyINR(wo.arReceivable)}</td>
                    <td className="p-3">
                      {wo.isPriorityAR ? (
                        <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold">
                          PRIORITY
                        </span>
                      ) : (
                        <span className="text-slate-500 text-[10px]">Standard</span>
                      )}
                    </td>
                    <td className="p-3">
                      {wo.anomalies.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {wo.anomalies.map((ano, aIdx) => (
                            <span key={aIdx} className="px-1.5 py-0.5 rounded bg-amber-950/40 border border-amber-500/30 text-[10px] text-amber-300 flex items-center space-x-1">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              <span>{ano}</span>
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Valid</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="p-3 bg-slate-950/70 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
          <span>Showing {activeBoard === 'deals' ? filteredDeals.length : filteredWOs.length} records</span>
          <span>All records sanitized & synchronized</span>
        </div>
      </div>
    </div>
  );
};
