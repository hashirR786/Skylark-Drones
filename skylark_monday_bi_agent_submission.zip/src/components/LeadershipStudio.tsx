import React, { useState } from 'react';
import { 
  FileText, 
  Copy, 
  Check, 
  Download, 
  Sparkles, 
  ShieldAlert, 
  CheckSquare, 
  TrendingUp, 
  Share2, 
  Printer,
  Calendar,
  Layers,
  Award
} from 'lucide-react';
import { Deal, WorkOrder, LeadershipUpdateReport } from '../types';
import { generateLeadershipReport, formatLeadershipUpdateAsMarkdown, formatLeadershipUpdateForSlack } from '../services/leadershipService';

interface LeadershipStudioProps {
  deals: Deal[];
  workOrders: WorkOrder[];
}

export const LeadershipStudio: React.FC<LeadershipStudioProps> = ({ deals, workOrders }) => {
  const [period, setPeriod] = useState<string>('Q4 FY25-26 (Current Quarter)');
  const [copiedType, setCopiedType] = useState<'md' | 'slack' | null>(null);

  const report: LeadershipUpdateReport = generateLeadershipReport(deals, workOrders, period);

  const handleCopyMarkdown = () => {
    const md = formatLeadershipUpdateAsMarkdown(report);
    navigator.clipboard.writeText(md);
    setCopiedType('md');
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleCopySlack = () => {
    const slack = formatLeadershipUpdateForSlack(report);
    navigator.clipboard.writeText(slack);
    setCopiedType('slack');
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadMarkdown = () => {
    const md = formatLeadershipUpdateAsMarkdown(report);
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Skylark_Executive_Briefing_${period.replace(/[^a-zA-Z0-9]/g, '_')}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Header & Export Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
              Leadership Briefing Studio
            </span>
            <span className="text-xs text-slate-400">Board & Executive Ready</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight mt-1 flex items-center space-x-2">
            <span>Executive Business Intelligence Update</span>
          </h1>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Period Selector */}
          <div className="flex items-center space-x-1.5 bg-slate-900 border border-slate-700 px-3 py-1.5 rounded-lg text-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              aria-label="Select Reporting Period"
              className="bg-transparent text-white font-medium outline-none"
            >
              <option value="Q4 FY25-26 (Current Quarter)" className="bg-slate-900">Q4 FY25-26 (Current Quarter)</option>
              <option value="Monthly Executive Review — Feb 2026" className="bg-slate-900">Monthly Review — Feb 2026</option>
              <option value="Annual Operating Plan Tracking FY25-26" className="bg-slate-900">Annual Plan Tracking FY25-26</option>
            </select>
          </div>

          <button
            onClick={handleCopySlack}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-teal-300 flex items-center space-x-1.5 transition-all"
            title="Copy Slack snippet formatted for executive channels"
          >
            {copiedType === 'slack' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied Slack</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5" />
                <span>Copy for Slack</span>
              </>
            )}
          </button>

          <button
            onClick={handleCopyMarkdown}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center space-x-1.5 transition-all"
            title="Copy as Markdown document"
          >
            {copiedType === 'md' ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied MD</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy MD</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadMarkdown}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 hover:opacity-90 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-teal-500/20 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .MD</span>
          </button>
        </div>
      </div>

      {/* Structured Executive Document Container */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-8 text-slate-100">
        {/* Document Header */}
        <div className="border-b border-slate-800/80 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">{report.title}</h2>
            <div className="text-xs text-slate-400 mt-0.5">
              Period: <strong className="text-teal-400">{report.period}</strong> | Generated: {report.date}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-medium">
              Live Monday.com Data
            </span>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="p-4 rounded-xl bg-teal-950/20 border border-teal-500/20 space-y-1.5">
          <div className="flex items-center space-x-1.5 text-xs font-bold text-teal-400 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-teal-400" />
            <span>Executive TL;DR</span>
          </div>
          <p className="text-sm text-slate-200 leading-relaxed">
            {report.executiveSummary}
          </p>
        </div>

        {/* Scorecard Cards */}
        <div>
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">
            Quarterly Operating Scorecard
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[11px] font-medium text-slate-400">Sales Pipeline Health</div>
              <div className="text-sm font-bold text-cyan-300 mt-1">{report.scorecard.pipelineHealth}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[11px] font-medium text-slate-400">Revenue Realization</div>
              <div className="text-sm font-bold text-emerald-400 mt-1">{report.scorecard.revenueRealization}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[11px] font-medium text-slate-400">Operational SLA Velocity</div>
              <div className="text-sm font-bold text-indigo-300 mt-1">{report.scorecard.operationalVelocity}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[11px] font-medium text-slate-400">Working Capital Risk</div>
              <div className="text-sm font-bold text-rose-400 mt-1">{report.scorecard.cashRisk}</div>
            </div>
          </div>
        </div>

        {/* Report Sections */}
        {report.sections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-3">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-1.5 flex items-center space-x-2">
              <span>{section.heading}</span>
            </h3>

            {/* Metric Chips */}
            {section.metrics && section.metrics.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {section.metrics.map((m, mIdx) => (
                  <div key={mIdx} className="p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/80 text-xs">
                    <div className="text-slate-400 text-[11px]">{m.label}</div>
                    <div className="font-bold text-slate-100 mt-0.5">{m.value}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Bullets */}
            <ul className="space-y-1.5 text-xs text-slate-300">
              {section.bullets.map((bullet, bIdx) => (
                <li key={bIdx} className="flex items-start space-x-2">
                  <span className="text-teal-400 mt-0.5">•</span>
                  <span dangerouslySetInnerHTML={{ __html: bullet.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') }} />
                </li>
              ))}
            </ul>
          </div>
        ))}

        {/* High Priority Strategic Risks Matrix */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-white border-b border-slate-800 pb-1.5 flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>High-Priority Risks & Operational Mitigations</span>
          </h3>

          <div className="overflow-x-auto rounded-xl border border-slate-800 custom-scrollbar">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Category</th>
                  <th className="p-3">Identified Risk</th>
                  <th className="p-3">Business Impact</th>
                  <th className="p-3">Mitigation Strategy</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {report.highPriorityRisks.map((risk, rIdx) => (
                  <tr key={rIdx} className="hover:bg-slate-800/30">
                    <td className="p-3 font-semibold text-rose-300">{risk.category}</td>
                    <td className="p-3">{risk.item}</td>
                    <td className="p-3 text-amber-300">{risk.impact}</td>
                    <td className="p-3 text-teal-300">{risk.mitigation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Items for Exec Team */}
        <div className="space-y-3">
          <h3 className="text-base font-bold text-white border-b border-slate-800 pb-1.5 flex items-center space-x-2">
            <CheckSquare className="w-4 h-4 text-teal-400" />
            <span>Strategic Action Items & Follow-ups</span>
          </h3>

          <div className="overflow-x-auto rounded-xl border border-slate-800 custom-scrollbar">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-3">Owner</th>
                  <th className="p-3">Strategic Task</th>
                  <th className="p-3">Timeline</th>
                  <th className="p-3">Priority</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {report.actionItems.map((action, aIdx) => (
                  <tr key={aIdx} className="hover:bg-slate-800/30">
                    <td className="p-3 font-bold text-white">{action.owner}</td>
                    <td className="p-3">{action.task}</td>
                    <td className="p-3 text-slate-400">{action.deadline}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        action.priority === 'HIGH' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {action.priority}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
