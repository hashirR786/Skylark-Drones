import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  ChevronRight, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  Download, 
  Copy, 
  Check, 
  Table, 
  HelpCircle,
  BarChart2,
  PieChart as PieIcon,
  Layers
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
} from 'recharts';
import { Deal, WorkOrder, QueryResult } from '../types';
import { processFounderQuery } from '../services/queryEngine';
import { formatCurrencyINR } from '../services/dataResilience';

interface ChatInterfaceProps {
  deals: Deal[];
  workOrders: WorkOrder[];
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  text?: string;
  result?: QueryResult;
  isLoading?: boolean;
}

const PRESET_QUERIES = [
  "How's our pipeline looking for energy sector this quarter?",
  "What is our total outstanding AR and priority risk accounts?",
  "Show operational delivery turnaround and execution delays in Mining",
  "Prepare an Executive Leadership Briefing for next week's board meeting",
  "Compare deals won vs operational work orders billed",
];

const COLORS = ['#14b8a6', '#0ea5e9', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899'];

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ deals, workOrders }) => {
  const [inputQuery, setInputQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: "Hello Founder! I am your **Skylark Drones Business Intelligence Agent**. I continuously monitor your **Sales Pipeline (346 Deals)** and **Project Execution (176 Work Orders)** across Monday.com.\n\nAsk me any question about revenue forecasts, sectoral performance, delivery velocity, or cash collection risks.",
    },
  ]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showDrilldown, setShowDrilldown] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isProcessing]);

  const handleSend = async (queryText?: string) => {
    const textToSubmit = queryText || inputQuery;
    if (!textToSubmit.trim() || isProcessing) return;

    const userMsgId = `user_${Date.now()}`;
    const assistantMsgId = `asst_${Date.now()}`;

    setMessages((prev) => [
      ...prev,
      {
        id: userMsgId,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: textToSubmit,
      },
      {
        id: assistantMsgId,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isLoading: true,
      },
    ]);

    setInputQuery('');
    setIsProcessing(true);

    try {
      // Simulate intelligent query processing
      const result = await processFounderQuery(textToSubmit, deals, workOrders);
      
      setTimeout(() => {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMsgId ? { ...msg, isLoading: false, result } : msg
          )
        );
        setIsProcessing(false);
      }, 400);
    } catch (err) {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMsgId
            ? {
                ...msg,
                isLoading: false,
                text: 'Sorry, I encountered an issue analyzing the Monday.com board data. Please try again.',
              }
            : msg
        )
      );
      setIsProcessing(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-6xl mx-auto p-4 sm:p-6">
      {/* Quick Prompt Suggestions */}
      <div className="mb-4">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-400 mb-2">
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Founder Quick Insights</span>
        </div>
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 custom-scrollbar">
          {PRESET_QUERIES.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              disabled={isProcessing}
              className="whitespace-nowrap px-3 py-1.5 rounded-lg bg-slate-900/90 hover:bg-teal-500/10 border border-slate-800 hover:border-teal-500/40 text-slate-300 hover:text-teal-300 text-xs transition-all flex items-center space-x-1.5 shadow-sm"
            >
              <span>{q}</span>
              <ChevronRight className="w-3 h-3 opacity-60" />
            </button>
          ))}
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-6">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start space-x-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-teal-600 to-cyan-500 p-0.5 shadow-md flex-shrink-0">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Bot className="w-4 h-4 text-teal-400" />
                </div>
              </div>
            )}

            {/* Message Bubble Content */}
            <div
              className={`max-w-3xl rounded-2xl p-4 sm:p-5 transition-all ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-teal-600 to-teal-700 text-white shadow-lg shadow-teal-900/20 ml-12'
                  : 'bg-slate-900/90 border border-slate-800/80 text-slate-100 shadow-xl w-full'
              }`}
            >
              {msg.sender === 'user' ? (
                <p className="text-sm font-medium leading-relaxed">{msg.text}</p>
              ) : msg.isLoading ? (
                <div className="flex items-center space-x-3 py-2">
                  <div className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping delay-100" />
                  <div className="w-2 h-2 rounded-full bg-indigo-400 animate-ping delay-200" />
                  <span className="text-xs text-slate-400 font-medium">
                    Querying Deals & Work Orders boards...
                  </span>
                </div>
              ) : msg.result ? (
                <div className="space-y-5">
                  {/* Top Badge & Confidence Score */}
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                        BI Intelligence Verified
                      </span>
                      <span className="text-xs text-slate-400">
                        Confidence: <strong className="text-emerald-400">{msg.result.confidenceScore}%</strong>
                      </span>
                    </div>
                    <button
                      onClick={() => copyToClipboard(msg.result?.summary || '', msg.id)}
                      className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs flex items-center space-x-1"
                      title="Copy response summary"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 text-[11px]">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span className="text-[11px]">Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Executive Summary */}
                  <div className="text-sm text-slate-200 leading-relaxed font-normal">
                    {msg.result.summary.split('\n\n').map((para, pIdx) => (
                      <p key={pIdx} className="mb-2 last:mb-0">
                        {para}
                      </p>
                    ))}
                  </div>

                  {/* KPI Metric Scorecards */}
                  {msg.result.keyMetrics && msg.result.keyMetrics.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                      {msg.result.keyMetrics.map((kpi, kIdx) => (
                        <div
                          key={kIdx}
                          className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 shadow-inner"
                        >
                          <div className="text-[11px] font-medium text-slate-400 truncate">
                            {kpi.label}
                          </div>
                          <div className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
                            {kpi.value}
                          </div>
                          {kpi.subtext && (
                            <div className="text-[10px] text-slate-500 mt-0.5 truncate">
                              {kpi.subtext}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Dynamic Visual Chart */}
                  {msg.result.chartConfig && msg.result.chartConfig.data.length > 0 && (
                    <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-300">
                          <BarChart2 className="w-4 h-4 text-teal-400" />
                          <span>{msg.result.chartConfig.title}</span>
                        </div>
                      </div>
                      <div className="h-56 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={msg.result.chartConfig.data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                            <XAxis
                              dataKey={msg.result.chartConfig.xAxisKey || 'name'}
                              stroke="#64748b"
                              fontSize={11}
                              tickLine={false}
                            />
                            <YAxis
                              stroke="#64748b"
                              fontSize={11}
                              tickLine={false}
                              tickFormatter={(v) => formatCurrencyINR(v, { compact: true, showSymbol: false })}
                            />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: '#090d16',
                                borderColor: '#334155',
                                borderRadius: '8px',
                                fontSize: '12px',
                              }}
                              formatter={(value: any) => [
                                typeof value === 'number' ? formatCurrencyINR(value) : value,
                                'Amount',
                              ]}
                            />
                            {msg.result.chartConfig.dataKeys.map((dk, dIdx) => (
                              <Bar key={dIdx} dataKey={dk.key} name={dk.name} radius={[4, 4, 0, 0]}>
                                {msg.result?.chartConfig?.data.map((_, idx) => (
                                  <Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                                ))}
                              </Bar>
                            ))}
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}

                  {/* Key Narrative Bullets */}
                  {msg.result.narrativeBullets && msg.result.narrativeBullets.length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      <div className="text-xs font-semibold text-teal-400 uppercase tracking-wider">
                        Operational & Sales Breakdown
                      </div>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {msg.result.narrativeBullets.map((bullet, bIdx) => (
                          <li key={bIdx} className="flex items-start space-x-2">
                            <span className="text-teal-400 mt-0.5">•</span>
                            <span>{bullet}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Strategic Insights */}
                  {msg.result.strategicInsights && msg.result.strategicInsights.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-teal-950/20 border border-teal-500/20 space-y-1.5">
                      <div className="flex items-center space-x-1.5 text-xs font-semibold text-teal-300">
                        <TrendingUp className="w-3.5 h-3.5 text-teal-400" />
                        <span>Founder Actionable Takeaways</span>
                      </div>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {msg.result.strategicInsights.map((insight, iIdx) => (
                          <li key={iIdx} className="flex items-start space-x-2">
                            <span className="text-teal-400 font-bold">→</span>
                            <span>{insight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Data Quality Caveats */}
                  {msg.result.dataQualityCaveats && msg.result.dataQualityCaveats.length > 0 && (
                    <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-500/20 flex items-start space-x-2 text-[11px] text-amber-300/90">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-amber-200">Data Resilience Caveat:</strong>{' '}
                        {msg.result.dataQualityCaveats.join(' ')}
                      </div>
                    </div>
                  )}

                  {/* Clarification Prompt Options (if query was ambiguous) */}
                  {msg.result.clarificationPrompt && (
                    <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/30 space-y-2">
                      <div className="flex items-center space-x-1.5 text-xs font-semibold text-indigo-300">
                        <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{msg.result.clarificationPrompt.question}</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {msg.result.clarificationPrompt.options.map((opt, oIdx) => (
                          <button
                            key={oIdx}
                            onClick={() => handleSend(opt)}
                            className="p-2.5 rounded-lg bg-slate-900 hover:bg-indigo-600/20 border border-slate-800 hover:border-indigo-500/40 text-left text-xs text-slate-200 transition-all flex items-center justify-between"
                          >
                            <span>{opt}</span>
                            <ChevronRight className="w-3 h-3 text-indigo-400" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Drilldown Data Toggle */}
                  {msg.result.drilldownData && (
                    <div className="pt-1">
                      <button
                        onClick={() => setShowDrilldown(showDrilldown === msg.id ? null : msg.id)}
                        className="text-xs font-medium text-teal-400 hover:text-teal-300 flex items-center space-x-1.5 underline"
                      >
                        <Table className="w-3.5 h-3.5" />
                        <span>
                          {showDrilldown === msg.id ? 'Hide Drilldown Records' : `View ${msg.result.drilldownData.rows.length} Drilldown Records`}
                        </span>
                      </button>

                      {showDrilldown === msg.id && (
                        <div className="mt-3 overflow-x-auto max-h-60 rounded-lg border border-slate-800 custom-scrollbar">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-slate-950 text-slate-400 font-semibold sticky top-0">
                              <tr>
                                {msg.result.drilldownData.columns.map((col) => (
                                  <th key={col.key} className="p-2.5 whitespace-nowrap">
                                    {col.label}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                              {msg.result.drilldownData.rows.map((row: any, rIdx: number) => (
                                <tr key={rIdx} className="hover:bg-slate-800/40">
                                  {msg.result?.drilldownData?.columns.map((col) => (
                                    <td key={col.key} className="p-2.5 whitespace-nowrap text-slate-300">
                                      {col.format === 'currency'
                                        ? formatCurrencyINR(row[col.key])
                                        : col.format === 'badge'
                                        ? (
                                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-teal-500/10 text-teal-300 border border-teal-500/20">
                                            {row[col.key]}
                                          </span>
                                        )
                                        : row[col.key] || '-'}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Suggested Next Inquiries */}
                  {msg.result.suggestedFollowups && msg.result.suggestedFollowups.length > 0 && (
                    <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
                      <span className="text-[11px] text-slate-400 font-medium">Suggested Next Steps:</span>
                      {msg.result.suggestedFollowups.map((sug, sIdx) => (
                        <button
                          key={sIdx}
                          onClick={() => handleSend(sug)}
                          className="text-[11px] px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-teal-300 hover:text-teal-200 transition-colors"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm leading-relaxed whitespace-pre-line text-slate-200">
                  {msg.text}
                </p>
              )}
            </div>

            {msg.sender === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-slate-300" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="mt-4 pt-3 border-t border-slate-800/80">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-center"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask a founder-level query (e.g. 'Pipeline in energy Q4', 'Top AR risk accounts', 'Delayed projects in Mining')..."
            className="w-full pl-4 pr-24 py-3.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 text-sm text-white placeholder-slate-400 transition-all outline-none shadow-lg"
            disabled={isProcessing}
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || isProcessing}
            className="absolute right-2 px-4 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 font-semibold text-xs flex items-center space-x-1.5 hover:opacity-90 disabled:opacity-50 transition-all shadow-md shadow-teal-500/20"
          >
            <span>Ask</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
        <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-slate-500">
          <span>Connected to Monday.com boards: Deal Funnel Tracker & Work Order Fulfillment</span>
          <span>Zero hallucination calculation engine</span>
        </div>
      </div>
    </div>
  );
};
