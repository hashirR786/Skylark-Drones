import React, { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  ShieldAlert, 
  Layers, 
  Users, 
  Filter,
  BarChart3,
  PieChart as PieIcon,
  ArrowUpRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Deal, WorkOrder, CrossBoardMetrics, SectorAnalytics } from '../types';
import { formatCurrencyINR, computeSectorBreakdown, computeOwnerPerformance } from '../services/dataResilience';

interface AnalyticsDashboardProps {
  deals: Deal[];
  workOrders: WorkOrder[];
  metrics: CrossBoardMetrics;
}

const COLORS = ['#14b8a6', '#0ea5e9', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899', '#6366f1'];

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  deals,
  workOrders,
  metrics,
}) => {
  const [selectedSector, setSelectedSector] = useState<string>('ALL');

  const sectorData = computeSectorBreakdown(deals, workOrders);
  const ownerData = computeOwnerPerformance(deals, workOrders);

  const filteredSectors = selectedSector === 'ALL' 
    ? sectorData 
    : sectorData.filter(s => s.sector.toLowerCase() === selectedSector.toLowerCase());

  const stageFunnelData = [
    { stage: 'Leads', count: deals.filter(d => d.dealStage.includes('Lead')).length, value: deals.filter(d => d.dealStage.includes('Lead')).reduce((a,b)=>a+b.dealValue, 0) },
    { stage: 'Qualified', count: deals.filter(d => d.dealStage.includes('Qualified')).length, value: deals.filter(d => d.dealStage.includes('Qualified')).reduce((a,b)=>a+b.dealValue, 0) },
    { stage: 'Proposal', count: deals.filter(d => d.dealStage.includes('Proposal')).length, value: deals.filter(d => d.dealStage.includes('Proposal')).reduce((a,b)=>a+b.dealValue, 0) },
    { stage: 'Negotiations', count: deals.filter(d => d.dealStage.includes('Negotiat')).length, value: deals.filter(d => d.dealStage.includes('Negotiat')).reduce((a,b)=>a+b.dealValue, 0) },
    { stage: 'Won / Signed', count: deals.filter(d => d.dealStage.includes('Won') || d.dealStage.includes('Work Order Received')).length, value: metrics.totalWonDealsValue },
  ];

  const executionStatusData = [
    { name: 'Completed', value: workOrders.filter(w => w.executionStatus === 'Completed').length, color: '#10b981' },
    { name: 'Ongoing', value: workOrders.filter(w => w.executionStatus.includes('Ongoing') || w.executionStatus.includes('In Progress')).length, color: '#38bdf8' },
    { name: 'Not Started', value: workOrders.filter(w => w.executionStatus === 'Not Started').length, color: '#f59e0b' },
    { name: 'Blocked / Pending', value: workOrders.filter(w => w.executionStatus.includes('Blocked') || w.executionStatus.includes('Pending') || w.executionStatus.includes('Pause')).length, color: '#ef4444' },
  ].filter(d => d.value > 0);

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Header & Sector Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center space-x-2">
            <span>Executive Analytics & Intelligence Hub</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Cross-board visibility across 346 deals and 176 operational work orders.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedSector}
            onChange={(e) => setSelectedSector(e.target.value)}
            aria-label="Filter by Sector"
            className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-semibold text-teal-300 outline-none focus:border-teal-500"
          >
            <option value="ALL">All Sectors ({sectorData.length})</option>
            {sectorData.map((s, idx) => (
              <option key={idx} value={s.sector}>
                {s.sector} ({formatCurrencyINR(s.pipelineValue)})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Gross Pipeline</span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-white tracking-tight mt-1">
            {formatCurrencyINR(metrics.totalPipelineValue)}
          </div>
          <div className="text-[11px] text-cyan-400 mt-0.5 flex items-center">
            <span>{deals.filter(d => d.dealStatus === 'Open').length} Open Deals</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Weighted Revenue</span>
            <DollarSign className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-xl font-bold text-teal-400 tracking-tight mt-1">
            {formatCurrencyINR(metrics.totalWeightedPipeline)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Probability adjusted
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Booked Won Deals</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 tracking-tight mt-1">
            {formatCurrencyINR(metrics.totalWonDealsValue)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {metrics.winRatePercent}% Win Conversion
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Operations Billed</span>
            <Layers className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xl font-bold text-indigo-300 tracking-tight mt-1">
            {formatCurrencyINR(metrics.totalBilledValue)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {workOrders.length} Work Orders
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Outstanding AR</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-bold text-rose-400 tracking-tight mt-1">
            {formatCurrencyINR(metrics.totalOutstandingAR)}
          </div>
          <div className="text-[11px] text-amber-400 mt-0.5">
            {formatCurrencyINR(metrics.priorityARValue)} Priority Risk
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>Delivery Velocity</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-white tracking-tight mt-1">
            {metrics.averageExecutionDays} Days
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            PO to Handover SLA
          </div>
        </div>
      </div>

      {/* Primary Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sector Pipeline vs Invoiced Comparison */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                <BarChart3 className="w-4 h-4 text-teal-400" />
                <span>Sectoral Pipeline vs Executed Invoicing</span>
              </h2>
              <p className="text-[11px] text-slate-400">Comparing forward pipeline against completed billing by sector</p>
            </div>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filteredSectors.slice(0, 6)} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="sector" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={(v) => formatCurrencyINR(v, { compact: true, showSymbol: false })} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(value: any) => [formatCurrencyINR(value), '']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Bar dataKey="pipelineValue" name="Gross Pipeline (₹)" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                <Bar dataKey="wonValue" name="Won Contracts (₹)" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="billedValue" name="Invoiced Operations (₹)" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Deal Stage Conversion Funnel */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <span>Deal Funnel Stage Conversion</span>
              </h2>
              <p className="text-[11px] text-slate-400">Total value progressing through pipeline milestones</p>
            </div>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stageFunnelData} layout="vertical" margin={{ top: 10, right: 20, left: 30, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                <XAxis type="number" stroke="#64748b" fontSize={11} tickLine={false} tickFormatter={(v) => formatCurrencyINR(v, { compact: true, showSymbol: false })} />
                <YAxis type="category" dataKey="stage" stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(value: any) => [formatCurrencyINR(value), 'Value']}
                />
                <Bar dataKey="value" name="Stage Value (₹)" radius={[0, 4, 4, 0]}>
                  {stageFunnelData.map((_, idx) => (
                    <Cell key={`funnel-cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Lower Row: Operations Execution Breakdown & Top Sales Owners */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Operational Status Donut */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl">
          <h2 className="text-sm font-bold text-white flex items-center space-x-2 mb-1">
            <PieIcon className="w-4 h-4 text-teal-400" />
            <span>Work Order Execution Status</span>
          </h2>
          <p className="text-[11px] text-slate-400 mb-3">Breakdown of 176 field deployments</p>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={executionStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {executionStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {executionStatusData.map((d, i) => (
              <div key={i} className="flex items-center space-x-2 text-[11px] text-slate-300">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="truncate">{d.name}: <strong>{d.value}</strong></span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Sales Reps / BD Personnel */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl lg:col-span-2">
          <h2 className="text-sm font-bold text-white flex items-center space-x-2 mb-1">
            <Users className="w-4 h-4 text-cyan-400" />
            <span>Sales BD/KAM Performance & Pipeline Contribution</span>
          </h2>
          <p className="text-[11px] text-slate-400 mb-3">Comparing deal origination, closed won contracts, and outstanding AR</p>
          
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/70 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="p-2.5">BD Owner</th>
                  <th className="p-2.5">Active Deals</th>
                  <th className="p-2.5">Open Pipeline</th>
                  <th className="p-2.5">Weighted Pipeline</th>
                  <th className="p-2.5">Won Contracts</th>
                  <th className="p-2.5">AR Outstanding</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {ownerData.slice(0, 6).map((o, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-semibold text-white">{o.owner}</td>
                    <td className="p-2.5">{o.totalDeals}</td>
                    <td className="p-2.5 text-cyan-300">{formatCurrencyINR(o.openPipeline)}</td>
                    <td className="p-2.5 text-teal-400 font-semibold">{formatCurrencyINR(o.weightedPipeline)}</td>
                    <td className="p-2.5 text-emerald-400">{formatCurrencyINR(o.wonValue)}</td>
                    <td className="p-2.5 text-rose-400">{formatCurrencyINR(o.arOutstanding)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
