import React, { useState } from 'react';
import { 
  X, 
  Key, 
  Layers, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ExternalLink, 
  Database,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { MondayConfig } from '../types';
import { testMondayConnection, fetchBoards } from '../services/mondayApi';

interface MondayConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: MondayConfig;
  onSaveConfig: (newConfig: MondayConfig) => void;
}

export const MondayConfigModal: React.FC<MondayConfigModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
}) => {
  const [apiKey, setApiKey] = useState(config.apiKey);
  const [dealsBoardId, setDealsBoardId] = useState(config.dealsBoardId);
  const [workOrdersBoardId, setWorkOrdersBoardId] = useState(config.workOrdersBoardId);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [discoveredBoards, setDiscoveredBoards] = useState<Array<{ id: string; name: string }>>([]);

  if (!isOpen) return null;

  const handleTest = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: 'Please enter a valid Monday.com API Token.' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await testMondayConnection(apiKey);
      if (res.success && res.user) {
        setTestResult({
          success: true,
          message: `Authenticated successfully as ${res.user.name} (${res.user.email})`,
        });

        // Auto fetch boards
        const boards = await fetchBoards(apiKey);
        setDiscoveredBoards(boards);
      } else {
        setTestResult({
          success: false,
          message: res.error || 'Authentication failed. Please verify your Monday.com API v2 token.',
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Connection failed',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = () => {
    onSaveConfig({
      apiKey,
      dealsBoardId,
      workOrdersBoardId,
      isConnected: Boolean(apiKey && testResult?.success),
      syncStatus: 'synced',
      lastSyncedAt: new Date().toLocaleTimeString(),
    });
    onClose();
  };

  const handleResetToDemo = () => {
    setApiKey('');
    setDealsBoardId('');
    setWorkOrdersBoardId('');
    setTestResult(null);
    onSaveConfig({
      apiKey: '',
      dealsBoardId: '',
      workOrdersBoardId: '',
      isConnected: false,
      syncStatus: 'idle',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-5 text-slate-100 animate-slide-up">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
              <Database className="w-4 h-4 text-blue-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Monday.com Live Integration Setup</h2>
              <p className="text-xs text-slate-400">Dynamic Board Querying & Authentication</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Instructions */}
        <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/20 text-xs text-blue-200 leading-relaxed">
          <p className="font-semibold text-blue-100 mb-1">
            Enterprise Monday.com v2 GraphQL Connection
          </p>
          <p>
            Connect your live Monday.com workspace using an API Personal Token. If left blank, the agent runs in <strong>Built-in Resilient Enterprise Mode</strong> with pre-normalized real data from the attached deals and work order trackers.
          </p>
        </div>

        {/* Input Fields */}
        <div className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
              <span className="flex items-center space-x-1.5">
                <Key className="w-3.5 h-3.5 text-teal-400" />
                <span>Monday.com Personal API Token</span>
              </span>
              <a
                href="https://support.monday.com/hc/en-us/articles/360005144820-How-to-get-your-API-key"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-teal-400 hover:underline flex items-center space-x-1"
              >
                <span>Where to get API token</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-600 focus:border-teal-500 outline-none font-mono"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Deals Funnel Board ID
              </label>
              <input
                type="text"
                value={dealsBoardId}
                onChange={(e) => setDealsBoardId(e.target.value)}
                placeholder="e.g. 1829472910"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-600 focus:border-teal-500 outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Work Orders Board ID
              </label>
              <input
                type="text"
                value={workOrdersBoardId}
                onChange={(e) => setWorkOrdersBoardId(e.target.value)}
                placeholder="e.g. 1829472911"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-600 focus:border-teal-500 outline-none font-mono"
              />
            </div>
          </div>

          {/* Test Status Banner */}
          {testResult && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start space-x-2 border ${
                testResult.success
                  ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-950/30 border-rose-500/30 text-rose-300'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              )}
              <span className="leading-tight">{testResult.message}</span>
            </div>
          )}

          {/* Discovered Boards Dropdown (if any) */}
          {discoveredBoards.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-[11px] font-semibold text-slate-400">Discovered Boards in Workspace:</span>
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto custom-scrollbar">
                {discoveredBoards.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => {
                      if (!dealsBoardId) setDealsBoardId(b.id);
                      else if (!workOrdersBoardId) setWorkOrdersBoardId(b.id);
                    }}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-teal-300 font-mono flex items-center space-x-1"
                  >
                    <span>{b.name}</span>
                    <span className="text-slate-500">({b.id})</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between border-t border-slate-800 pt-4">
          <button
            onClick={handleResetToDemo}
            className="text-xs text-slate-400 hover:text-white underline"
          >
            Reset to Built-in Demo Mode
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleTest}
              disabled={isTesting || !apiKey.trim()}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white flex items-center space-x-1.5 disabled:opacity-50 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin text-teal-400' : ''}`} />
              <span>Test API</span>
            </button>

            <button
              onClick={handleSave}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 hover:opacity-90 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-teal-500/20 transition-all"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Save & Connect</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
