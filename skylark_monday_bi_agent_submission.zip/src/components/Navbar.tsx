import React from 'react';
import { 
  Bot, 
  BarChart3, 
  FileText, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Settings, 
  Sparkles,
  Plane
} from 'lucide-react';
import { MondayConfig, CrossBoardMetrics } from '../types';

interface NavbarProps {
  activeTab: 'chat' | 'dashboard' | 'leadership' | 'explorer' | 'monday';
  setActiveTab: (tab: 'chat' | 'dashboard' | 'leadership' | 'explorer' | 'monday') => void;
  mondayConfig: MondayConfig;
  metrics: CrossBoardMetrics;
  onOpenConfig: () => void;
  isSyncing: boolean;
  onSync: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  mondayConfig,
  metrics,
  onOpenConfig,
  isSyncing,
  onSync,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-[#070d19]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 via-teal-500 to-cyan-400 p-0.5 shadow-lg shadow-teal-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Plane className="w-5 h-5 text-teal-400 transform -rotate-45" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg text-white tracking-tight">SKYLARK</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                  DRONES BI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Founder Executive Agent</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'chat'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>AI Agent Chat</span>
              <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Analytics Hub</span>
            </button>

            <button
              onClick={() => setActiveTab('leadership')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'leadership'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Leadership Briefings</span>
            </button>

            <button
              onClick={() => setActiveTab('explorer')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'explorer'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow-md shadow-teal-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Data Explorer</span>
            </button>
          </nav>

          {/* Right Status & Integration Controls */}
          <div className="flex items-center space-x-3">
            {/* Data Quality Indicator */}
            <div className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-xs">
              <span className="text-slate-400">Data Resilience:</span>
              <span className="font-semibold text-emerald-400">{metrics.dataQualityScore}%</span>
            </div>

            {/* Monday.com Live Status */}
            <button
              onClick={onOpenConfig}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                mondayConfig.isConnected
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20'
                  : 'bg-blue-500/10 border-blue-500/30 text-blue-300 hover:bg-blue-500/20'
              }`}
              title="Configure Monday.com API Connection & Boards"
            >
              <div className={`w-2 h-2 rounded-full ${mondayConfig.isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-blue-400'}`} />
              <span className="hidden sm:inline">
                {mondayConfig.isConnected ? 'Monday.com: Connected' : 'Monday.com: Demo Mode'}
              </span>
              <Settings className="w-3.5 h-3.5 opacity-75" />
            </button>

            {/* Sync Button */}
            <button
              onClick={onSync}
              disabled={isSyncing}
              className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-all disabled:opacity-50"
              title="Refresh / Re-sync Board Data"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-teal-400' : ''}`} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
